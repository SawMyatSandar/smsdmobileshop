<!DOCTYPE html>
<html>
<head>
	<title>SMSD Mobile Shop</title>
	<!-- Latest compiled and minified CSS -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
	<!-- Optional theme -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
	<!-- Latest compiled and minified JavaScript -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>

	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="stylesheet" type="text/css" href="css/style.css">

</head>
<body>

<!--Navigation Bar-->
	<nav class="navbar navbar-default">
	  	<div class="container-fluid">
	  		<div class="navbar-header">
	  			<img src="images/smsdmobilelogo.PNG" width="25%" height="25%">
	  		</div>
		    <div class="navbar-header">
		      <a class="navbar-brand" href="index.html">SMSD MOBILE SHOP</a>
		    </div>

<div id="searchbox" style="margin-left: 80%;margin-top: 3%;">
	 <form action="product1.php" method="get">
		<input type="text" placeholder="Enter Search" name="filter"/>
		<input type="submit" value="Search">
	 </form>
</div>


		    <ul class="nav navbar-nav">
		      <li class="active"><a href="index.html">Home</a></li>
		      <li><a href="product.php">Product</a></li>
		      <li><a href="aboutus.html">About Us</a></li>
		      <li><a href="contactus.html">Contact Us</a></li>
		    </ul>
	  </div>
	</nav>
<!--End of Navigation Bar-->

<?php		
	$filter=$_GET['filter'];
	include('admin/database.php');
	$result = mysql_query("SELECT * FROM product where pname like '%$filter%'");
        
		if($result){				
			while($row=mysql_fetch_array($result)){
					$id = $row["pid"];	
					echo '<ul class="col-sm-3">';
					echo '<div class="product-image-wrapper">
						  <div class="single-products">
						  <div class="productinfo text-center">
					<a href="product1.php?id='.$id.'" rel="bookmark" pname="'.$row['pname'].'"><img src="images/'.$row['pphoto'].'" alt="'.$row['pname'].'" pname="'.$row['pname'].'" width="250" height="250" /></a>
                    </a>
                    	</div>';	
					echo 'Name: '.$row['pname'].'';?><br>
					<?echo 'Description: '.$row['pdescription'].'';?><br>
					<?echo 'Price: '.$row['pprice'].'';?><br>
				<?
					echo '</ul>';			
				}
				}
				?>

<!--Footer-->
<footer class="page-footer font-small">
	<div class="container">
		<div class="row text-center d-flex justify-content-center pt-5 mb-3">
			<div class="col-md-12 mb-3">
				<h6 class="text-uppercase font-weight-bold">
					<a href="aboutus.html">Home</a>
				</h6>
			</div>			

			<div class="col-md-12 mb-3">
				<h6 class="text-uppercase font-weight-bold">
					<a href="aboutus.html">Product</a>
				</h6>
			</div>
			<div class="col-md-12 mb-3">
				<h6 class="text-uppercase font-weight-bold">
					<a href="aboutus.html">About Us</a>
				</h6>
			</div>
			<div class="col-md-12 mb-3">
				<h6 class="text-uppercase font-weight-bold">
					<a href="aboutus.html">Contact Us</a>
				</h6>
 			</div>
		</div>
	</div>

	<div class="text-center">
	      <!-- Add font awesome icons -->
	    <a href="https://web.facebook.com/" class="fa fa-facebook"> </a>
	    <a href="https://web.facebook.com/" class="fa fa-twitter"></a>
	    <a href="https://www.youtube.com/" class="fa fa-youtube"></a>
	    <a href="https://www.google.com/" class="fa fa-google"></a>
	    <a href="https://www.google.com/" class="fa fa-skype"></a>        
	</div>
	  
	  <div class="footer-copyright text-center">©2020 Copyright:SMSDMobileShop
	  </div>

</footer>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<!--End of Footer-->
</body>
</html>