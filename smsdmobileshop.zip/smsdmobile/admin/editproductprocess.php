<?php
include("database.php");
echo $pid=$_POST['pid'];
echo $pname = $_POST['pname'];
echo $pdescription = $_POST['pdescription'];
echo $pprice = $_POST['pprice'];
echo $pedate = $_POST['pedate'];
$pphoto = $_POST['pphoto'];

$sql = "UPDATE product SET pname='$pname', pdescription='$pdescription', pprice='$pprice', pedate='$pedate', pphoto='$pphoto' WHERE pid =$pid";
mysql_query($sql);
header("location: viewproduct.php");
?>
