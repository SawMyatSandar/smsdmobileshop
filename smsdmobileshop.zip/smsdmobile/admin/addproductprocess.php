<?php
include("database.php");

$pname = $_POST['pname'];
$pdescription = $_POST['pdescription'];
$pprice = $_POST['pprice'];
$pedate = $_POST['pedate'];
$pphoto = $_POST['pphoto'];
$sql = "INSERT INTO product (pname,pdescription,pprice,pedate,pphoto) VALUES ('$pname','$pdescription','$pprice','$pedate','$pphoto')";
mysql_query($sql);
header("location: cpanel.php");
?>