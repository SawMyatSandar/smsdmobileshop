<?php
include("database.php");
echo $uid=$_POST['uid'];
echo $username = $_POST['username'];
echo $password = $_POST['password'];

$sql = "UPDATE login SET username='$username', password='$password' WHERE uid =$uid";
mysql_query($sql);
header("location: viewuser.php");
?>
