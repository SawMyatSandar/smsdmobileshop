<?php
include 'database.php';
$sql = "DELETE FROM product WHERE pid='".$_GET["id"]."'";
mysql_query($sql);
?>
<script>
alert("Delete Successfully");
window.location = "viewproduct.php";
</script>
